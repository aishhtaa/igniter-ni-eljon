<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Lost Item</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">


    <!-- navigation -->
    <nav class="navbar navbar-dark bg-primary">

        <div class="container">

            <a
                class="navbar-brand"
                href="<?php echo base_url('ProjectController'); ?>"
            >
                Lost and Found
            </a>

            <a
                href="<?php echo base_url('ProjectController'); ?>"
                class="btn btn-light btn-sm"
            >
                Back
            </a>

        </div>

    </nav>


    <!-- main container -->
    <div class="container mt-4 mb-5">

        <div class="card shadow-sm">

            <div class="card-body">

                <h4 class="mb-4">
                    Edit Lost Item
                </h4>


                <!-- validation errors -->
                <?php

                echo validation_errors(
                    '<div class="alert alert-danger">',
                    '</div>'
                );

                ?>


                <!-- form -->
                <form
                    method="post"
                    action="<?php echo base_url('ProjectController/update/' . $item->id); ?>"
                    enctype="multipart/form-data"
                >

                    <div class="row">


                        <!-- student id -->
                        <div class="col-md-6 mb-3">

                            <label
                                for="student_id"
                                class="form-label"
                            >
                                Student ID
                            </label>

                            <input
                                type="text"
                                id="student_id"
                                name="student_id"
                                class="form-control"
                                value="<?php echo html_escape($item->student_id); ?>"
                                required
                            >

                        </div>


                        <!-- item name -->
                        <div class="col-md-6 mb-3">

                            <label
                                for="item_name"
                                class="form-label"
                            >
                                Item Name
                            </label>

                            <input
                                type="text"
                                id="item_name"
                                name="item_name"
                                class="form-control"
                                value="<?php echo html_escape($item->item_name); ?>"
                                required
                            >

                        </div>


                        <!-- location -->
                        <div class="col-md-6 mb-3">

                            <label
                                for="location"
                                class="form-label"
                            >
                                Location Lost
                            </label>

                            <input
                                type="text"
                                id="location"
                                name="location"
                                class="form-control"
                                value="<?php echo html_escape($item->location); ?>"
                                required
                            >

                        </div>


                        <!-- date -->
                        <div class="col-md-6 mb-3">

                            <label
                                for="date_lost"
                                class="form-label"
                            >
                                Date Lost
                            </label>

                            <input
                                type="date"
                                id="date_lost"
                                name="date_lost"
                                class="form-control"
                                value="<?php echo html_escape($item->date_lost); ?>"
                                required
                            >

                        </div>


                        <!-- contact -->
                        <div class="col-12 mb-3">

                            <label
                                for="contact"
                                class="form-label"
                            >
                                Contact Information
                            </label>

                            <input
                                type="text"
                                id="contact"
                                name="contact"
                                class="form-control"
                                value="<?php echo html_escape($item->contact); ?>"
                                required
                            >

                        </div>


                        <!-- description -->
                        <div class="col-12 mb-3">

                            <label
                                for="description"
                                class="form-label"
                            >
                                Description
                            </label>

                            <textarea
                                id="description"
                                name="description"
                                class="form-control"
                                rows="4"
                                required
                            ><?php echo html_escape($item->description); ?></textarea>

                        </div>


                        <!-- image -->
                        <div class="col-12 mb-3">

                            <label
                                for="image"
                                class="form-label"
                            >
                                Item Image
                            </label>


                            <?php if (!empty($item->image)): ?>

                                <div class="mb-3">

                                    <img
                                        src="<?php echo base_url(
                                            'uploads/items/' . $item->image
                                        ); ?>"
                                        class="img-thumbnail"
                                        style="max-width: 250px; max-height: 200px;"
                                        alt="Lost Item Image"
                                    >

                                </div>

                            <?php endif; ?>


                            <input
                                type="file"
                                id="image"
                                name="image"
                                class="form-control"
                                accept="image/*"
                            >

                            <small class="text-muted">
                                Leave empty if you do not want to change the image.
                            </small>

                        </div>


                        <!-- status -->
                        <div class="col-md-6 mb-4">

                            <label
                                for="status"
                                class="form-label"
                            >
                                Status
                            </label>

                            <select
                                id="status"
                                name="status"
                                class="form-select"
                                required
                            >

                                <option
                                    value="Lost"
                                    <?php
                                    if ($item->status == 'Lost') {
                                        echo 'selected';
                                    }
                                    ?>
                                >
                                    Lost
                                </option>

                                <option
                                    value="Found"
                                    <?php
                                    if ($item->status == 'Found') {
                                        echo 'selected';
                                    }
                                    ?>
                                >
                                    Found
                                </option>

                            </select>

                        </div>


                        <!-- buttons -->
                        <div class="col-12">

                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Update
                            </button>

                            <a
                                href="<?php echo base_url('ProjectController'); ?>"
                                class="btn btn-secondary"
                            >
                                Cancel
                            </a>

                        </div>


                    </div>

                </form>

            </div>

        </div>

    </div>


</body>

</html>