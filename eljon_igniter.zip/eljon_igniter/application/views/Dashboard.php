<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">


<!-- navigation -->

<nav class="navbar navbar-dark bg-primary">

    <div class="container">

        <a
            class="navbar-brand"
            href="<?php echo base_url('ProjectController'); ?>"
        >
            Lost and Found
        </a>

        <div>

            <a
                href="<?php echo base_url('ProjectController'); ?>"
                class="btn btn-light btn-sm"
            >
                Home
            </a>

            <a
                href="<?php echo base_url('logout'); ?>"
                class="btn btn-outline-light btn-sm"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<!-- dashboard -->

<div class="container mt-4">

    <div class="text-center mb-4">

        <h2>
            Lost and Found Dashboard
        </h2>

        <p class="text-muted">
            Overview of lost and found items.
        </p>

    </div>


    <!-- cards -->

    <div class="row mb-4">


        <div class="col-md-4 mb-3">

            <div class="card text-center">

                <div class="card-body">

                    <h5>
                        Total Items
                    </h5>

                    <h2>
                        <?php echo $total; ?>
                    </h2>

                </div>

            </div>

        </div>


        <div class="col-md-4 mb-3">

            <div class="card text-center">

                <div class="card-body">

                    <h5>
                        Lost Items
                    </h5>

                    <h2>
                        <?php echo $lost; ?>
                    </h2>

                </div>

            </div>

        </div>


        <div class="col-md-4 mb-3">

            <div class="card text-center">

                <div class="card-body">

                    <h5>
                        Found Items
                    </h5>

                    <h2>
                        <?php echo $found; ?>
                    </h2>

                </div>

            </div>

        </div>


    </div>


    <!-- graph -->

    <div class="card">

        <div class="card-body">

            <h5 class="mb-4">
                Lost and Found Items
            </h5>

            <canvas id="itemsChart"></canvas>

        </div>

    </div>


</div>


<!-- chart -->

<script
    src="https://cdn.jsdelivr.net/npm/chart.js">
</script>


<script>

var lost = <?php echo $lost; ?>;

var found = <?php echo $found; ?>;


var ctx = document
    .getElementById('itemsChart')
    .getContext('2d');


new Chart(ctx, {

    type: 'bar',

    data: {

        labels: [
            'Lost',
            'Found'
        ],

        datasets: [{

            label: 'Number of Items',

            data: [
                lost,
                found
            ]

        }]

    },

    options: {

        responsive: true,

        scales: {

            y: {

                beginAtZero: true,

                ticks: {

                    stepSize: 1

                }

            }

        }

    }

});

</script>


</body>

</html>