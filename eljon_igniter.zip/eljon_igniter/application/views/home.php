<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, sans-serif;
        }

        body{
            background:linear-gradient(135deg,#4facfe,#00f2fe);
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .container{
            background:#fff;
            padding:40px;
            border-radius:15px;
            text-align:center;
            box-shadow:0 8px 20px rgba(0,0,0,.2);
            width:350px;
        }

        h1{
            color:#333;
            margin-bottom:20px;
        }

        p{
            color:#666;
            margin-bottom:25px;
        }

        a{
            text-decoration:none;
            background:#007BFF;
            color:white;
            padding:12px 25px;
            border-radius:8px;
            transition:.3s;
            display:inline-block;
        }

        a:hover{
            background:#0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Home</h1>
    <p>Welcome to the Home Page.</p>

    <a href="<?php echo site_url('HomeController/about'); ?>">Go to About</a>
    <br>
    <br>
    <a href="<?php echo site_url('HomeController/Studentdb'); ?>">Student Form</a>
</div>

</body>
</html>