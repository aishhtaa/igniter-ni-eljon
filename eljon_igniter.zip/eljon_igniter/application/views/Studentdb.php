<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Form</title>
</head>
<body>

		<h2>Student Form</h2>

<form action="<?php echo site_url('HomeController/save'); ?>"
		method="post">

    Fullname:<br>
    <input type="text" name="fullname"><br><br>

    Email:<br>
    <input type="text" name="email"><br><br>

    Course:<br>
    <input type="text" name="course"><br><br>

    Year Level:<br>
    <input type="number" name="year_level"><br><br>

    Address:<br>
    <input type="text" name="address"><br><br>

    Contact Number:<br>
    <input type="number" name="contact_number"><br><br>

    <input type="submit" name="submit" value="Save">

</form>

<hr>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Fullname</th>
        <th>Email</th>
        <th>Course</th>
        <th>Year Level</th>
        <th>Address</th>
        <th>Contact Number</th>
        <th>Controls</th>
    </tr>

    <?php 
    if (!empty($students)) {
    	foreach ($students as $row) {
	?>
    <tr>
    	<td><?php echo $row->id; ?></td>
        <td><?php echo $row->fullname; ?></td>
        <td><?php echo $row->email; ?></td>
        <td><?php echo $row->course; ?></td>
        <td><?php echo $row->year_level; ?></td>
        <td><?php echo $row->address; ?></td>
        <td><?php echo $row->contact_number; ?></td>
        <td>
            <a href="<?php echo base_url('HomeController/edit/'. $row->id); ?>">Edit</a>

            <a href="<?= base_url('HomeController/delete/'.$row->id); ?>"
            onclick="return confirm('Are you sure you want to delete this student?');"> Delete</a>
            </td>   
        </tr>
    <?php 
				}} 	
	?>
</table>
</html>