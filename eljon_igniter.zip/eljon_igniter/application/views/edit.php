<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<form action="<?php echo site_url('HomeController/update/'.$student->id); ?>" method="post">

    <label>Full Name</label>
    <input type="text" name="fullname"
           value="<?php echo $student->fullname; ?>">

    <label>Email</label>
    <input type="email" name="email"
           value="<?php echo $student->email; ?>">

    <label>Course</label>
    <input type="text" name="course"
           value="<?php echo $student->course; ?>">

    <label>Year Level</label>
    <input type="text" name="year_level"
           value="<?php echo $student->year_level; ?>">

    <label>Address</label>
    <input type="text" name="address"
           value="<?php echo $student->address; ?>">

    <label>Contact Number</label>
    <input type="text" name="contact_number"
           value="<?php echo $student->contact_number; ?>">

    <button type="submit" name="submit" value="1">
        Update
    </button>

</form>
	

</body>
</html>