<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>

    <style>
        body{
            margin:0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(to right, #74ebd5, #ACB6E5);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
        }

        .about-box{
            background:#fff;
            width:400px;
            padding:30px;
            border-radius:15px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
            text-align:center;
        }

        h2{
            color:#333;
            margin-bottom:15px;
        }

        p{
            color:#666;
            line-height:1.6;
            font-size:16px;
        }

        .btn{
            display:inline-block;
            margin-top:20px;
            padding:10px 20px;
            background:#4CAF50;
            color:white;
            text-decoration:none;
            border-radius:8px;
            transition:0.3s;
        }

        .btn:hover{
            background:#388E3C;
        }
    </style>
</head>
<body>

    <div class="about-box">
        <h2>About</h2>

        <p>
            Lamat Gard
            
        </p>

        <a href="<?php echo site_url('HomeController/index'); ?>" class="btn">Home</a>
    </div>

</body>
</html>