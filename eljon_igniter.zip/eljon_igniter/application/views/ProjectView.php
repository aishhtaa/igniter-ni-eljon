<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Lost and Found</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"
    >

</head>

<body>

<nav class="navbar navbar-dark bg-dark">

    <div class="container">

        <a class="navbar-brand" href="<?= site_url('ProjectController') ?>">
            Lost and Found
        </a>

        <div>

            <a
                href="<?= site_url('ProjectController/dashboard') ?>"
                class="btn btn-outline-light btn-sm"
            >
                Dashboard
            </a>

            <a
                href="<?= site_url('ProjectController/logout') ?>"
                class="btn btn-danger btn-sm"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-center">

        <div>

            <h2>Lost and Found System</h2>

            <p class="text-muted">
                Report and find lost items.
            </p>

        </div>

        <a
            href="#report"
            class="btn btn-primary"
        >
            Report Item
        </a>

    </div>


    <!-- messages -->

    <?php if ($this->session->flashdata('success')): ?>

        <div class="alert alert-success">

            <?= $this->session->flashdata('success') ?>

        </div>

    <?php endif; ?>


    <?php if ($this->session->flashdata('error')): ?>

        <div class="alert alert-danger">

            <?= $this->session->flashdata('error') ?>

        </div>

    <?php endif; ?>


    <!-- report -->

    <div
        class="card mt-4"
        id="report"
    >

        <div class="card-header">

            <h5 class="mb-0">
                Report a Lost Item
            </h5>

        </div>

        <div class="card-body">

            <?= validation_errors('<div class="alert alert-danger">', '</div>') ?>

            <form
                action="<?= site_url('ProjectController/save') ?>"
                method="post"
                enctype="multipart/form-data"
            >

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Student ID
                        </label>

                        <input
                            type="text"
                            name="student_id"
                            class="form-control"
                            placeholder="Enter Student ID"
                            required
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Item Name
                        </label>

                        <input
                            type="text"
                            name="item_name"
                            class="form-control"
                            placeholder="Enter Item Name"
                            required
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Location Lost
                        </label>

                        <input
                            type="text"
                            name="location"
                            class="form-control"
                            placeholder="Enter Location"
                            required
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Date Lost
                        </label>

                        <input
                            type="date"
                            name="date_lost"
                            class="form-control"
                            required
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Contact Information
                        </label>

                        <input
                            type="text"
                            name="contact"
                            class="form-control"
                            placeholder="Enter Contact Number"
                            required
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Item Image
                        </label>

                        <input
                            type="file"
                            name="image"
                            class="form-control"
                            accept="image/*"
                        >

                    </div>


                    <div class="col-12 mb-3">

                        <label class="form-label">
                            Description
                        </label>

                        <textarea
                            name="description"
                            class="form-control"
                            rows="3"
                            placeholder="Enter Description"
                            required
                        ></textarea>

                    </div>

                </div>


                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Add Item
                </button>

                <button
                    type="reset"
                    class="btn btn-secondary"
                >
                    Clear
                </button>

            </form>

        </div>

    </div>


    <!-- lost items -->

    <h4 class="mt-5 mb-3">
        Lost Items
    </h4>


    <div class="row">

        <?php if (!empty($items)): ?>

            <?php foreach ($items as $item): ?>

                <div class="col-md-6 mb-4">

                    <div class="card h-100">

                        <?php if (!empty($item->image)): ?>

                            <img
                                src="<?= base_url('uploads/items/' . $item->image) ?>"
                                class="card-img-top"
                                style="height: 250px; object-fit: cover;"
                            >

                        <?php endif; ?>


                        <div class="card-body">

                            <div class="d-flex justify-content-between">

                                <h5 class="card-title">

                                    <?= html_escape($item->item_name) ?>

                                </h5>

                                <span class="badge bg-danger">

                                    <?= html_escape($item->status) ?>

                                </span>

                            </div>


                            <p class="mb-1">

                                <strong>Student ID:</strong>

                                <?= html_escape($item->student_id) ?>

                            </p>


                            <p class="mb-1">

                                <strong>Location:</strong>

                                <?= html_escape($item->location) ?>

                            </p>


                            <p class="mb-1">

                                <strong>Date Lost:</strong>

                                <?= html_escape($item->date_lost) ?>

                            </p>


                            <p class="mb-1">

                                <strong>Contact:</strong>

                                <?= html_escape($item->contact) ?>

                            </p>


                            <p>

                                <strong>Description:</strong>

                                <?= html_escape($item->description) ?>

                            </p>


                            <!-- buttons -->

                            <div class="mb-3">

                                <a
                                    href="<?= site_url('ProjectController/edit/' . $item->id) ?>"
                                    class="btn btn-warning btn-sm"
                                >
                                    Edit
                                </a>


                                <a
                                    href="<?= site_url('ProjectController/delete/' . $item->id) ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure you want to delete this item?')"
                                >
                                    Delete
                                </a>


                                <button
                                    type="button"
                                    class="btn btn-primary btn-sm"
                                    data-bs-toggle="modal"
                                    data-bs-target="#notifyModal<?= $item->id ?>"
                                >
                                    Notify Me
                                </button>

                            </div>


                            <!-- comments -->

                            <hr>

                            <h6>
                                Comments
                            </h6>


                            <?php if (!empty($item->comments)): ?>

                                <?php foreach ($item->comments as $comment): ?>

                                    <div class="border rounded p-2 mb-2">

                                        <strong>
                                            Student ID:
                                            <?= html_escape($comment->student_id) ?>
                                        </strong>

                                        <p class="mb-1">

                                            <?= html_escape($comment->comment) ?>

                                        </p>

                                        <small class="text-muted">

                                            <?= html_escape($comment->created_at) ?>

                                        </small>

                                    </div>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <p class="text-muted">

                                    No comments yet.

                                </p>

                            <?php endif; ?>


                            <!-- comment form -->

                            <form
                                action="<?= site_url('ProjectController/comment/' . $item->id) ?>"
                                method="post"
                            >

                                <div class="mb-2">

                                    <input
                                        type="text"
                                        name="student_id"
                                        class="form-control"
                                        placeholder="Student ID"
                                        required
                                    >

                                </div>


                                <div class="mb-2">

                                    <textarea
                                        name="comment"
                                        class="form-control"
                                        placeholder="Write a comment..."
                                        rows="2"
                                        required
                                    ></textarea>

                                </div>


                                <button
                                    type="submit"
                                    class="btn btn-primary btn-sm"
                                >
                                    Post Comment
                                </button>

                            </form>

                        </div>

                    </div>

                </div>


                <!-- notify modal -->

                <div
                    class="modal fade"
                    id="notifyModal<?= $item->id ?>"
                    tabindex="-1"
                >

                    <div class="modal-dialog">

                        <div class="modal-content">

                            <form
                                action="<?= site_url('ProjectController/notify/' . $item->id) ?>"
                                method="post"
                            >

                                <div class="modal-header">

                                    <h5 class="modal-title">
                                        Notify Student
                                    </h5>

                                    <button
                                        type="button"
                                        class="btn-close"
                                        data-bs-dismiss="modal"
                                    ></button>

                                </div>


                                <div class="modal-body">

                                    <div class="mb-3">

                                        <label class="form-label">
                                            Student ID
                                        </label>

                                        <input
                                            type="text"
                                            name="student_id"
                                            class="form-control"
                                            required
                                        >

                                    </div>


                                    <div class="mb-3">

                                        <label class="form-label">
                                            Email
                                        </label>

                                        <input
                                            type="email"
                                            name="email"
                                            class="form-control"
                                            required
                                        >

                                    </div>

                                </div>


                                <div class="modal-footer">

                                    <button
                                        type="button"
                                        class="btn btn-secondary"
                                        data-bs-dismiss="modal"
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="submit"
                                        class="btn btn-primary"
                                    >
                                        Send Notification
                                    </button>

                                </div>

                            </form>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="col-12">

                <div class="alert alert-info">

                    No lost items have been posted yet.

                </div>

            </div>

        <?php endif; ?>

    </div>

</div>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

<script
    src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"
></script>


<?php if ($this->session->flashdata('success')): ?>

<script>

    alertify.success(
        <?= json_encode($this->session->flashdata('success')) ?>
    );

</script>

<?php endif; ?>


<?php if ($this->session->flashdata('error')): ?>

<script>

    alertify.error(
        <?= json_encode($this->session->flashdata('error')) ?>
    );

</script>

<?php endif; ?>

</body>

</html>