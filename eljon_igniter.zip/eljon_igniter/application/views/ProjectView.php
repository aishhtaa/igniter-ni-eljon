<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Lost and Found</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">


<!-- navigation -->

<nav class="navbar navbar-dark bg-primary">

    <div class="container">

        <a
            href="<?php echo base_url('ProjectController'); ?>"
            class="btn btn-sm btn-light">
            <h5>Home</h5>
        </a>

        <a
             href="#report"
             class="btn btn-sm btn-outline-light">
            <h5>Report Item</h5>
        </a>

        <a
            href="<?php echo base_url('dashboard'); ?>"
            class="btn btn-sm btn-warning">
            <h5>Admin Panel</h5>
        </a>

        <a
            href="<?php echo base_url('logout'); ?>"
            class="btn btn-sm btn-danger">
            <h5>Logout</h5>
        </a>

    </div>

</div>

</nav>


<div class="container mt-4">


<!-- homepage -->

<div class="text-center mb-4">

    <h2>
        Lost and Found System
    </h2>

    <p class="text-muted">
        Report and find lost items.
    </p>

</div>


<!-- report -->

<div
    class="card mb-4"
    id="report">

    <div class="card-body">

        <h5 class="mb-4">
            Report a Lost Item
        </h5>


        <?php echo validation_errors(
            '<div class="alert alert-danger">',
            '</div>'
        ); ?>


        <form
            method="post"
            action="<?php echo base_url(
                'ProjectController/save'
            ); ?>"
            enctype="multipart/form-data">


            <div class="row">


                <div class="col-md-6 mb-3">

                    <label class="form-label">
                        Student ID
                    </label>

                    <input
                        type="text"
                        name="student_id"
                        class="form-control"
                        placeholder="Enter Student ID"
                        value="<?php echo set_value('student_id'); ?>"
                        required>

                </div>


                <div class="col-md-6 mb-3">

                    <label class="form-label">
                        Item Name
                    </label>

                    <input
                        type="text"
                        name="item_name"
                        class="form-control"
                        placeholder="Enter item name"
                        value="<?php echo set_value('item_name'); ?>"
                        required>

                </div>


                <div class="col-md-6 mb-3">

                    <label class="form-label">
                        Location Lost
                    </label>

                    <input
                        type="text"
                        name="location"
                        class="form-control"
                        placeholder="Where was it lost?"
                        value="<?php echo set_value('location'); ?>"
                        required>

                </div>


                <div class="col-md-6 mb-3">

                    <label class="form-label">
                        Date Lost
                    </label>

                    <input
                        type="date"
                        name="date_lost"
                        class="form-control"
                        value="<?php echo set_value('date_lost'); ?>"
                        required>

                </div>


                <div class="col-12 mb-3">

                    <label class="form-label">
                        Contact Information
                    </label>

                    <input
                        type="text"
                        name="contact"
                        class="form-control"
                        placeholder="Email or phone number"
                        value="<?php echo set_value('contact'); ?>"
                        required>

                </div>


                <div class="col-12 mb-3">

                    <label class="form-label">
                        Description
                    </label>

                    <textarea
                        name="description"
                        class="form-control"
                        rows="4"
                        placeholder="Describe the lost item"
                        required><?php echo set_value('description'); ?></textarea>

                </div>


                <!-- image -->

                <div class="col-12 mb-3">

                    <label class="form-label">
                        Item Image
                    </label>

                    <input
                        type="file"
                        name="image"
                        class="form-control"
                        accept="image/*">

                    <small class="text-muted">
                        Upload an image of the lost item.
                    </small>

                </div>


                <div class="col-12">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Add Item
                    </button>

                    <button
                        type="reset"
                        class="btn btn-secondary">
                        Clear
                    </button>

                </div>


            </div>

        </form>

    </div>

</div>


<!-- lost items -->

<div class="card mb-4">

    <div class="card-body">

        <h5 class="mb-4">
            Lost Items
        </h5>


        <?php if (!empty($items)): ?>


            <div class="row">


                <?php foreach ($items as $row): ?>


                    <div class="col-md-6 mb-3">

                        <div class="card h-100">

                            <div class="card-body">


                                <div
                                    class="d-flex justify-content-between"
                                >

                                    <h5 class="mb-3">

                                        <?php echo html_escape($row->item_name); ?>

                                    </h5>


                                    <span
                                        class="badge bg-danger"
                                    >

                                        <?php echo html_escape($row->status); ?>

                                    </span>

                                </div>


                                <!-- image -->

                                <?php if (!empty($row->image)): ?>

                                    <div class="mb-3">

                                        <img
                                            src="<?php echo base_url(
                                                'uploads/items/' . $row->image
                                            ); ?>"
                                            class="img-fluid rounded"
                                            style="max-height: 250px; width: 100%; object-fit: contain;"
                                            alt="Lost Item Image"
                                        >

                                    </div>

                                <?php endif; ?>


                                <p class="mb-1">

                                    <strong>
                                        Student ID:
                                    </strong>

                                    <?php echo html_escape($row->student_id); ?>

                                </p>


                                <p class="mb-1">

                                    <strong>
                                        Location:
                                    </strong>

                                    <?php echo html_escape($row->location); ?>

                                </p>


                                <p class="mb-1">

                                    <strong>
                                        Date:
                                    </strong>

                                    <?php echo html_escape($row->date_lost); ?>

                                </p>


                                <p class="mb-1">

                                    <strong>
                                        Contact:
                                    </strong>

                                    <?php echo html_escape($row->contact); ?>

                                </p>


                                <p>

                                    <strong>
                                        Description:
                                    </strong>

                                    <br>

                                    <?php echo html_escape($row->description); ?>

                                </p>


                                <a
                                    href="<?php echo base_url(
                                        'ProjectController/edit/' . $row->id
                                    ); ?>"
                                    class="btn btn-warning btn-sm">
                                    Edit
                                </a>


                                <a
                                    href="<?php echo base_url(
                                        'ProjectController/delete/' .
                                        $row->id
                                    ); ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm(
                                        'Are you sure you want to delete this item?'
                                    );">
                                    Delete
                                </a>


                                <button
                                    type="button"
                                    class="btn btn-success btn-sm"
                                    onclick="notifyStudent(
                                        <?php echo $row->id; ?>
                                    )">
                                    Notify Me
                                </button>


                            </div>

                        </div>

                    </div>


                <?php endforeach; ?>


            </div>


        <?php else: ?>


            <div class="alert alert-secondary mb-0">

                No lost items available.

            </div>


        <?php endif; ?>


    </div>

</div>


</div>


<!-- notification -->

<form
    id="notifyForm"
    method="post"
    style="display: none;"
>

    <input
        type="hidden"
        name="student_id"
        id="notifyStudentId"
    >

    <input
        type="hidden"
        name="email"
        id="notifyEmail"
    >

</form>


<script
    src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js">
</script>


<script>

function notifyStudent(itemId)
{
    var studentId = prompt(
        "Enter your Student ID:"
    );

    if (studentId === null)
    {
        return;
    }

    if (studentId.trim() === "")
    {
        alertify.error(
            "Student ID is required."
        );

        return;
    }

    var email = prompt(
        "Enter your Email Address:"
    );

    if (email === null)
    {
        return;
    }

    if (email.trim() === "")
    {
        alertify.error(
            "Email is required."
        );

        return;
    }

    document.getElementById(
        "notifyStudentId"
    ).value = studentId;

    document.getElementById(
        "notifyEmail"
    ).value = email;

    document.getElementById(
        "notifyForm"
    ).action =
    "<?php echo base_url('project/notify/'); ?>" + itemId;

    document.getElementById(
        "notifyForm"
    ).submit();
}


<?php if ($this->session->flashdata('success')): ?>

alertify.success(
    "<?php echo addslashes($this->session->flashdata('success')); ?>"
);

<?php endif; ?>


<?php if ($this->session->flashdata('error')): ?>

alertify.error(
    "<?php echo addslashes($this->session->flashdata('error')); ?>"
);

<?php endif; ?>

</script>


</body>

</html>