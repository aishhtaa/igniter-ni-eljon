<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="row justify-content-center">

        <div class="col-md-5">

            <div class="card">

                <div class="card-body">

                    <h3 class="text-center mb-4">
                        Admin Login
                    </h3>

                    <?php if ($this->session->flashdata('error')): ?>

                        <div class="alert alert-danger">
                            <?= $this->session->flashdata('error'); ?>
                        </div>

                    <?php endif; ?>

                    <form method="post"
                          action="<?= base_url('ProjectController/check_login'); ?>">

                        <div class="mb-3">

                            <label class="form-label">
                                Username
                            </label>

                            <input
                                type="text"
                                name="username"
                                class="form-control"
                                required
                            >

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Password
                            </label>

                            <input
                                type="password"
                                name="password"
                                class="form-control"
                                required
                            >

                        </div>

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            Login
                        </button>

                    </form>

                    <div class="text-center mt-3">

                        <a href="<?= base_url('ProjectController'); ?>">
                            Back to Lost & Found
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>