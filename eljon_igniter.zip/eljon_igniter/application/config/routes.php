<?php

$route['default_controller'] = 'ProjectController';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// save
$route['save'] = 'HomeController/Studentdb';

// notify
$route['project/notify/(:num)'] = 'ProjectController/notify/$1';

// project
$route['project'] = 'ProjectController';

$route['project/edit/(:num)'] = 'ProjectController/edit/$1';

$route['project/update/(:num)'] = 'ProjectController/update/$1';

$route['project/delete/(:num)'] = 'ProjectController/delete/$1';

// login
$route['login'] = 'ProjectController/login';
$route['login/check'] = 'ProjectController/check_login';
$route['logout'] = 'ProjectController/logout';

// dashboard
$route['dashboard'] = 'ProjectController/dashboard';

// excel
$route['project/import_excel'] = 'ProjectController/import_excel';