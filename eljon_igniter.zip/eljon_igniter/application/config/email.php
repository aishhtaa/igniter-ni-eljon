<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = '2087411@g.cu.edu.ph';
$config['smtp_pass'] = 'xtegbsrkilrpxong';
$config['smtp_crypto'] = 'tls';
$config['smtp_timeout'] = 30;

$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";
$config['crlf'] = "\r\n";