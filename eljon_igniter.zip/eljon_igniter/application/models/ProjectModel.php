<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProjectModel extends CI_Model
{
    private $table = 'lost_found_items';
    private $notification_table = 'lost_found_notifications';

    // fetch
    public function get_items()
    {
        return $this->db
            ->order_by('id', 'DESC')
            ->get($this->table)
            ->result();
    }

    // get one
    public function get_item($id)
    {
        return $this->db
            ->where('id', $id)
            ->get($this->table)
            ->row();
    }

    // insert
    public function insert_item($data)
    {
        return $this->db->insert(
            $this->table,
            $data
        );
    }

    // update
    public function update_item($id, $data)
    {
        return $this->db
            ->where('id', $id)
            ->update($this->table, $data);
    }

    // delete
    public function delete_item($id)
    {
        return $this->db
            ->where('id', $id)
            ->delete($this->table);
    }

    // notify
    public function create_notification($data)
    {
        return $this->db->insert(
            $this->notification_table,
            $data
        );
    }

    // dashboard
    public function count_lost()
    {
        return $this->db
            ->where('status', 'Lost')
            ->count_all_results($this->table);
    }

    public function count_found()
    {
        return $this->db
            ->where('status', 'Found')
            ->count_all_results($this->table);
    }

    // comments
    public function get_comments($item_id)
    {
        $this->db->where('item_id', $item_id);
        $this->db->order_by('id', 'ASC');

        return $this->db
            ->get('lost_found_comments')
            ->result();
    }

    public function add_comment($data)
    {
        return $this->db->insert(
            'lost_found_comments',
            $data
        );
    }
}