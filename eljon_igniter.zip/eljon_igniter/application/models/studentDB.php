<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class studentDB extends CI_Model
{
   

     public function insertStudents($data)
    {
        return $this->db->insert('students', $data);
    }

    public function fetchStudents()
    {
        return $this->db->get('students')->result();
    }

    public function get_Id_Student($id)
    {
    return $this->db
                ->where('id', $id)
                ->get('students')
                ->row();
    }

    public function  updateStudent($id, $data)
    {
    return $this->db
                ->where('id', $id)
                ->update('students', $data);
    }

    public function deleteStudent($id)
    {
    $this->db->where('id', $id);
    return $this->db->delete('students');
  }
 
}
			