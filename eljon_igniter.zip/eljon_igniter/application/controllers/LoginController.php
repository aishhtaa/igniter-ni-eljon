<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Admin_model');
        $this->load->library('session');
        $this->load->helper('url');
    }

    // login
    public function index()
    {
        if ($this->session->userdata('admin_logged_in')) {
            redirect('AdminController');
        }

        $this->load->view('admin/Login');
    }

    // login check
    public function login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $admin = $this->Admin_model->login($username, $password);

        if ($admin) {

            $session_data = array(
                'admin_id' => $admin->id,
                'admin_username' => $admin->username,
                'admin_logged_in' => TRUE
            );

            $this->session->set_userdata($session_data);

            redirect('AdminController');

        } else {

            $this->session->set_flashdata(
                'error',
                'Invalid username or password.'
            );

            redirect('LoginController');
        }
    }

    // logout
    public function logout()
    {
        $this->session->sess_destroy();

        redirect('LoginController');
    }
}