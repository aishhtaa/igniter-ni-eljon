<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProjectController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('ProjectModel');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('email');
        $this->load->helper(array('url', 'form'));
    }

    // homepage
    public function index()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $data['items'] = $this->ProjectModel->get_items();

        foreach ($data['items'] as $item) {
            $item->comments =
                $this->ProjectModel->get_comments($item->id);
        }

        $this->load->view('ProjectView', $data);
    }

    // login
    public function login()
    {
        if ($this->session->userdata('admin_logged_in')) {
            redirect('ProjectController');
        }

        $this->load->view('admin/Login');
    }

    // check login
    public function check_login()
    {
        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password', TRUE);

        if ($username == 'admin' && $password == 'admin123') {

            $this->session->set_userdata(array(
                'admin_logged_in' => TRUE,
                'admin_username' => 'admin'
            ));

            $this->session->set_flashdata(
                'success',
                'Login successful.'
            );

            redirect('ProjectController');

        } else {

            $this->session->set_flashdata(
                'error',
                'Invalid username or password.'
            );

            redirect('ProjectController/login');
        }
    }

    // logout
    public function logout()
    {
        $this->session->sess_destroy();

        redirect('ProjectController/login');
    }

    // save
    public function save()
    {
        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim|numeric'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim|alpha'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim|alpha'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim|numeric'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim|alpha_numeric_spaces'
        );

        if ($this->form_validation->run() == FALSE) {

            $data['items'] =
                $this->ProjectModel->get_items();

            foreach ($data['items'] as $item) {
                $item->comments =
                    $this->ProjectModel->get_comments($item->id);
            }

            $this->load->view(
                'ProjectView',
                $data
            );

            return;
        }

        // upload
        $image = '';

        if (!empty($_FILES['image']['name'])) {

            $config['upload_path'] =
                './uploads/items/';

            $config['allowed_types'] =
                'jpg|jpeg|png|gif';

            $config['max_size'] =
                2048;

            $config['encrypt_name'] =
                TRUE;

            $this->load->library(
                'upload',
                $config
            );

            if ($this->upload->do_upload('image')) {

                $upload_data =
                    $this->upload->data();

                $image =
                    $upload_data['file_name'];

            } else {

                $this->session->set_flashdata(
                    'error',
                    $this->upload->display_errors()
                );

                redirect('ProjectController');
            }
        }

        // insert
        $data = array(
            'student_id' =>
                $this->input->post(
                    'student_id',
                    TRUE
                ),

            'item_name' =>
                $this->input->post(
                    'item_name',
                    TRUE
                ),

            'description' =>
                $this->input->post(
                    'description',
                    TRUE
                ),

            'location' =>
                $this->input->post(
                    'location',
                    TRUE
                ),

            'date_lost' =>
                $this->input->post(
                    'date_lost',
                    TRUE
                ),

            'contact' =>
                $this->input->post(
                    'contact',
                    TRUE
                ),

            'status' =>
                'Lost',

            'image' =>
                $image
        );

        if ($this->ProjectModel->insert_item($data)) {

            $this->session->set_flashdata(
                'success',
                'Lost item added successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to add lost item.'
            );
        }

        redirect('ProjectController');
    }

    // edit
    public function edit($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $data['item'] =
            $this->ProjectModel->get_item($id);

        if (!$data['item']) {

            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        $this->load->view(
            'ProjectEdit',
            $data
        );
    }

    // update
    public function update($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim|numeric'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim|alpha'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim|alpha'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim|numeric'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim|alpha_numeric_spaces'
        );

        if ($this->form_validation->run() == FALSE) {

            $data['item'] =
                $this->ProjectModel->get_item($id);

            $this->load->view(
                'ProjectEdit',
                $data
            );

            return;
        }

        // get old item
        $old_item =
            $this->ProjectModel->get_item($id);

        // update
        $data = array(
            'student_id' =>
                $this->input->post(
                    'student_id',
                    TRUE
                ),

            'item_name' =>
                $this->input->post(
                    'item_name',
                    TRUE
                ),

            'description' =>
                $this->input->post(
                    'description',
                    TRUE
                ),

            'location' =>
                $this->input->post(
                    'location',
                    TRUE
                ),

            'date_lost' =>
                $this->input->post(
                    'date_lost',
                    TRUE
                ),

            'contact' =>
                $this->input->post(
                    'contact',
                    TRUE
                ),

            'status' =>
                $this->input->post(
                    'status',
                    TRUE
                )
        );

        // upload
        if (!empty($_FILES['image']['name'])) {

            $config['upload_path'] =
                './uploads/items/';

            $config['allowed_types'] =
                'jpg|jpeg|png|gif';

            $config['max_size'] =
                2048;

            $config['encrypt_name'] =
                TRUE;

            $this->load->library(
                'upload',
                $config
            );

            if ($this->upload->do_upload('image')) {

                $upload_data =
                    $this->upload->data();

                $data['image'] =
                    $upload_data['file_name'];

                if (!empty($old_item->image)) {

                    $old_image =
                        './uploads/items/' .
                        $old_item->image;

                    if (file_exists($old_image)) {
                        unlink($old_image);
                    }
                }

            } else {

                $this->session->set_flashdata(
                    'error',
                    $this->upload->display_errors()
                );

                redirect(
                    'ProjectController/edit/' . $id
                );
            }
        }

        if ($this->ProjectModel->update_item($id, $data)) {

            $this->session->set_flashdata(
                'success',
                'Lost item updated successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to update lost item.'
            );
        }

        redirect('ProjectController');
    }

    // delete
    public function delete($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        if ($this->ProjectModel->delete_item($id)) {

            $this->session->set_flashdata(
                'success',
                'Lost item deleted successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to delete lost item.'
            );
        }

        redirect('ProjectController');
    }

    // dashboard
    public function dashboard()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $data['lost'] =
            $this->ProjectModel->count_lost();

        $data['found'] =
            $this->ProjectModel->count_found();

        $data['total'] =
            $data['lost'] +
            $data['found'];

        $this->load->view(
            'Dashboard',
            $data
        );
    }

    // notify
    public function notify($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $student_id =
            $this->input->post(
                'student_id',
                TRUE
            );

        $email =
            $this->input->post(
                'email',
                TRUE
            );

        if (empty($student_id)) {

            $this->session->set_flashdata(
                'error',
                'Student ID is required.'
            );

            redirect('ProjectController');
        }

        if (empty($email)) {

            $this->session->set_flashdata(
                'error',
                'Email is required.'
            );

            redirect('ProjectController');
        }

        if (!filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )) {

            $this->session->set_flashdata(
                'error',
                'Please enter a valid email address.'
            );

            redirect('ProjectController');
        }

        $item =
            $this->ProjectModel->get_item($id);

        if (!$item) {

            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        // notification
        $data = array(
            'item_id' =>
                $id,

            'student_id' =>
                $student_id,

            'message' =>
                'Student ' .
                $student_id .
                ' was notified about ' .
                $item->item_name
        );

        if (!$this->ProjectModel->create_notification($data)) {

            $this->session->set_flashdata(
                'error',
                'Notification failed.'
            );

            redirect('ProjectController');
        }

        // email
        $this->email->from(
            $this->config->item('smtp_user'),
            'Lost and Found System'
        );

        $this->email->to($email);

        $this->email->subject(
            'Lost and Found Notification - ' .
            $item->item_name
        );

        $message = '
            <h3>Lost and Found Notification</h3>

            <p>Hello,</p>

            <p>
                Your lost item has been matched
                with a reported item.
            </p>

            <p>
                <strong>Student ID:</strong>
                ' . html_escape($student_id) . '
            </p>

            <p>
                <strong>Item Name:</strong>
                ' . html_escape($item->item_name) . '
            </p>

            <p>
                <strong>Description:</strong>
                ' . html_escape($item->description) . '
            </p>

            <p>
                <strong>Location:</strong>
                ' . html_escape($item->location) . '
            </p>

            <p>
                <strong>Date Lost:</strong>
                ' . html_escape($item->date_lost) . '
            </p>

            <p>
                <strong>Contact:</strong>
                ' . html_escape($item->contact) . '
            </p>

            <p>
                Please check the attached image of the item.
            </p>

            <p>Thank you.</p>
        ';

        $this->email->message($message);

        // attachment
        if (!empty($item->image)) {

            $file_path =
                FCPATH .
                'uploads/items/' .
                $item->image;

            if (file_exists($file_path)) {

                $this->email->attach(
                    $file_path
                );

            } else {

                $this->session->set_flashdata(
                    'error',
                    'Email attachment was not found.'
                );

                redirect('ProjectController');
            }
        }

        if ($this->email->send(FALSE)) {

            $this->session->set_flashdata(
                'success',
                'Notification recorded and email sent successfully.'
            );

        } else {

            echo '<pre>';

            echo $this->email->print_debugger();

            echo '</pre>';

            exit;
        }

        redirect('ProjectController');
    }

    // excel
    public function import_excel()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        if (empty($_FILES['excel_file']['name'])) {

            $this->session->set_flashdata(
                'error',
                'Please select an Excel file.'
            );

            redirect('ProjectController');
        }

        $extension =
            strtolower(
                pathinfo(
                    $_FILES['excel_file']['name'],
                    PATHINFO_EXTENSION
                )
            );

        if (!in_array(
            $extension,
            array('xlsx', 'xls')
        )) {

            $this->session->set_flashdata(
                'error',
                'Please upload an Excel file.'
            );

            redirect('ProjectController');
        }

        require_once FCPATH .
            'vendor/autoload.php';

        $file =
            $_FILES['excel_file']['tmp_name'];

        try {

            $spreadsheet =
                \PhpOffice\PhpSpreadsheet\IOFactory::load(
                    $file
                );

            $sheet =
                $spreadsheet->getActiveSheet();

            $rows =
                $sheet->toArray();

            $drawings =
                $sheet->getDrawingCollection();

            $images = array();

            foreach ($drawings as $drawing) {

                $coordinates =
                    $drawing->getCoordinates();

                list(
                    $column,
                    $row_number
                ) =
                    \PhpOffice\PhpSpreadsheet\Cell\Coordinate::coordinateFromString(
                        $coordinates
                    );

                if (strtoupper($column) != 'G') {
                    continue;
                }

                $image_name =
                    uniqid('item_') .
                    '.png';

                $image_path =
                    FCPATH .
                    'uploads/items/' .
                    $image_name;

                if (
                    $drawing instanceof
                    \PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing
                ) {

                    $image_resource =
                        $drawing->getImageResource();

                    if ($image_resource) {

                        imagepng(
                            $image_resource,
                            $image_path
                        );
                    }

                } else {

                    $source =
                        $drawing->getPath();

                    if (
                        !empty($source) &&
                        file_exists($source)
                    ) {

                        copy(
                            $source,
                            $image_path
                        );
                    }
                }

                if (file_exists($image_path)) {

                    $images[$row_number] =
                        $image_name;
                }
            }

            foreach ($rows as $key => $row) {

                if ($key == 0) {
                    continue;
                }

                if (
                    empty($row[0]) ||
                    empty($row[1]) ||
                    empty($row[2]) ||
                    empty($row[3]) ||
                    empty($row[4]) ||
                    empty($row[5])
                ) {
                    continue;
                }

                $excel_row =
                    $key + 1;

                $image = '';

                if (isset($images[$excel_row])) {

                    $image =
                        $images[$excel_row];
                }

                $data = array(
                    'student_id' =>
                        trim($row[0]),

                    'item_name' =>
                        trim($row[1]),

                    'description' =>
                        trim($row[2]),

                    'location' =>
                        trim($row[3]),

                    'date_lost' =>
                        trim($row[4]),

                    'contact' =>
                        trim($row[5]),

                    'status' =>
                        'Lost',

                    'image' =>
                        $image
                );

                $this->ProjectModel
                    ->insert_item($data);
            }

            $this->session->set_flashdata(
                'success',
                'Excel file imported successfully.'
            );

        } catch (Exception $e) {

            $this->session->set_flashdata(
                'error',
                'Failed to import Excel file: ' .
                $e->getMessage()
            );
        }

        redirect('ProjectController');
    }

    // export excel
    public function export_excel()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        require_once FCPATH .
            'vendor/autoload.php';

        $items =
            $this->ProjectModel->get_items();

        $spreadsheet =
            new \PhpOffice\PhpSpreadsheet\Spreadsheet();

        $sheet =
            $spreadsheet->getActiveSheet();

        // headers
        $sheet->setCellValue(
            'A1',
            'Student ID'
        );

        $sheet->setCellValue(
            'B1',
            'Item Name'
        );

        $sheet->setCellValue(
            'C1',
            'Description'
        );

        $sheet->setCellValue(
            'D1',
            'Location'
        );

        $sheet->setCellValue(
            'E1',
            'Date Lost'
        );

        $sheet->setCellValue(
            'F1',
            'Contact'
        );

        $sheet->setCellValue(
            'G1',
            'Image'
        );

        $row = 2;

        foreach ($items as $item) {

            $sheet->setCellValue(
                'A' . $row,
                $item->student_id
            );

            $sheet->setCellValue(
                'B' . $row,
                $item->item_name
            );

            $sheet->setCellValue(
                'C' . $row,
                $item->description
            );

            $sheet->setCellValue(
                'D' . $row,
                $item->location
            );

            $sheet->setCellValue(
                'E' . $row,
                $item->date_lost
            );

            $sheet->setCellValue(
                'F' . $row,
                $item->contact
            );

            // image
            if (!empty($item->image)) {

                $image_path =
                    FCPATH .
                    'uploads/items/' .
                    $item->image;

                if (file_exists($image_path)) {

                    $extension =
                        strtolower(
                            pathinfo(
                                $image_path,
                                PATHINFO_EXTENSION
                            )
                        );

                    $image_resource = false;

                    if (
                        $extension == 'jpg' ||
                        $extension == 'jpeg'
                    ) {

                        $image_resource =
                            imagecreatefromjpeg(
                                $image_path
                            );

                    } elseif (
                        $extension == 'png'
                    ) {

                        $image_resource =
                            imagecreatefrompng(
                                $image_path
                            );

                    } elseif (
                        $extension == 'gif'
                    ) {

                        $image_resource =
                            imagecreatefromgif(
                                $image_path
                            );
                    }

                    if ($image_resource) {

                        $drawing =
                            new \PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing();

                        $drawing->setName(
                            'Item Image'
                        );

                        $drawing->setDescription(
                            'Lost Item Image'
                        );

                        $drawing->setImageResource(
                            $image_resource
                        );

                        $drawing->setRenderingFunction(
                            \PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing::RENDERING_PNG
                        );

                        $drawing->setMimeType(
                            \PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing::MIMETYPE_DEFAULT
                        );

                        $drawing->setCoordinates(
                            'G' . $row
                        );

                        $drawing->setHeight(80);

                        $drawing->setOffsetX(5);
                        $drawing->setOffsetY(5);

                        $drawing->setWorksheet(
                            $sheet
                        );

                        imagedestroy(
                            $image_resource
                        );
                    }
                }
            }

            $sheet->getRowDimension(
                $row
            )->setRowHeight(90);

            $row++;
        }

        // column width
        $sheet->getColumnDimension('A')
            ->setWidth(20);

        $sheet->getColumnDimension('B')
            ->setWidth(20);

        $sheet->getColumnDimension('C')
            ->setWidth(25);

        $sheet->getColumnDimension('D')
            ->setWidth(20);

        $sheet->getColumnDimension('E')
            ->setWidth(15);

        $sheet->getColumnDimension('F')
            ->setWidth(20);

        $sheet->getColumnDimension('G')
            ->setWidth(20);

        $filename =
            'lost_found_items.xlsx';

        $writer =
            new \PhpOffice\PhpSpreadsheet\Writer\Xlsx(
                $spreadsheet
            );

        header(
            'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );

        header(
            'Content-Disposition: attachment; filename="' .
            $filename .
            '"'
        );

        header(
            'Cache-Control: max-age=0'
        );

        $writer->save(
            'php://output'
        );

        exit;
    }

    // comment
    public function comment($item_id)
    {
        $student_id =
            $this->input->post(
                'student_id',
                TRUE
            );

        $comment =
            $this->input->post(
                'comment',
                TRUE
            );

        if (
            empty($student_id) ||
            empty($comment)
        ) {

            $this->session->set_flashdata(
                'error',
                'Student ID and comment are required.'
            );

            redirect('ProjectController');
        }

        $item =
            $this->ProjectModel->get_item(
                $item_id
            );

        if (!$item) {

            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        $data = array(
            'item_id' =>
                $item_id,

            'student_id' =>
                $student_id,

            'comment' =>
                $comment
        );

        if ($this->ProjectModel->add_comment($data)) {

            $this->session->set_flashdata(
                'success',
                'Comment added successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to add comment.'
            );
        }

        redirect('ProjectController');
    }
}