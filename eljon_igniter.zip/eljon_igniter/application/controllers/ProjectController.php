<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProjectController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('ProjectModel');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper(array('url', 'form'));
    }

    // homepage
    public function index()
    {
        $data['items'] = $this->ProjectModel->get_items();

        $this->load->view('ProjectView', $data);
    }

    // save
    public function save()
    {
        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim'
        );

        if ($this->form_validation->run() == FALSE) {
            $data['items'] = $this->ProjectModel->get_items();

            $this->load->view('ProjectView', $data);
            return;
        }

        // insert
        $data = array(
            'student_id' => $this->input->post('student_id', TRUE),
            'item_name' => $this->input->post('item_name', TRUE),
            'description' => $this->input->post('description', TRUE),
            'location' => $this->input->post('location', TRUE),
            'date_lost' => $this->input->post('date_lost', TRUE),
            'contact' => $this->input->post('contact', TRUE),
            'status' => 'Lost'
        );

        if ($this->ProjectModel->insert_item($data)) {
            $this->session->set_flashdata(
                'success',
                'Lost item added successfully.'
            );
        } else {
            $this->session->set_flashdata(
                'error',
                'Failed to add lost item.'
            );
        }

        redirect('ProjectController');
    }

    // edit
    public function edit($id)
    {
        $data['item'] = $this->ProjectModel->get_item($id);

        if (!$data['item']) {
            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        $this->load->view('ProjectEdit', $data);
    }

    // update
    public function update($id)
    {
        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim'
        );

        if ($this->form_validation->run() == FALSE) {
            $data['item'] = $this->ProjectModel->get_item($id);

            $this->load->view('ProjectEdit', $data);
            return;
        }

        // update
        $data = array(
            'student_id' => $this->input->post('student_id', TRUE),
            'item_name' => $this->input->post('item_name', TRUE),
            'description' => $this->input->post('description', TRUE),
            'location' => $this->input->post('location', TRUE),
            'date_lost' => $this->input->post('date_lost', TRUE),
            'contact' => $this->input->post('contact', TRUE),
            'status' => $this->input->post('status', TRUE)
        );

        if ($this->ProjectModel->update_item($id, $data)) {
            $this->session->set_flashdata(
                'success',
                'Lost item updated successfully.'
            );
        } else {
            $this->session->set_flashdata(
                'error',
                'Failed to update lost item.'
            );
        }

        redirect('ProjectController');
    }

    // delete
    public function delete($id)
    {
        if ($this->ProjectModel->delete_item($id)) {
            $this->session->set_flashdata(
                'success',
                'Lost item deleted successfully.'
            );
        } else {
            $this->session->set_flashdata(
                'error',
                'Failed to delete lost item.'
            );
        }

        redirect('ProjectController');
    }

    // notify
    public function notify($id)
    {
        $student_id = $this->input->post('student_id', TRUE);

        if (empty($student_id)) {
            $this->session->set_flashdata(
                'error',
                'Student ID is required.'
            );

            redirect('ProjectController');
        }

        $item = $this->ProjectModel->get_item($id);

        if (!$item) {
            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        // notification
        $data = array(
            'item_id' => $id,
            'student_id' => $student_id,
            'message' =>
                'Student ' . $student_id .
                ' was notified about ' . $item->item_name
        );

        if ($this->ProjectModel->create_notification($data)) {
            $this->session->set_flashdata(
                'success',
                'Student notification recorded.'
            );
        } else {
            $this->session->set_flashdata(
                'error',
                'Notification failed.'
            );
        }

        redirect('ProjectController');
    }
}