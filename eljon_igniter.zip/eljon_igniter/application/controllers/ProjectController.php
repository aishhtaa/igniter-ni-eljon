<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProjectController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('ProjectModel');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('email');
        $this->load->helper(array('url', 'form'));
    }

   // homepage
    public function index()
    {
    if (!$this->session->userdata('admin_logged_in')) {
        redirect('ProjectController/login');
    }

    $data['items'] = $this->ProjectModel->get_items();

    $this->load->view('ProjectView', $data);
    }

    // login
    public function login()
    {
        if ($this->session->userdata('admin_logged_in')) {
            redirect('ProjectController');
        }

        $this->load->view('admin/Login');
    }

    // check login
    public function check_login()
    {
        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password', TRUE);

        if ($username == 'admin' && $password == 'admin123') {

            $this->session->set_userdata(array(
                'admin_logged_in' => TRUE,
                'admin_username' => 'admin'
            ));

            $this->session->set_flashdata(
                'success',
                'Login successful.'
            );

            redirect('ProjectController');

        } else {

            $this->session->set_flashdata(
                'error',
                'Invalid username or password.'
            );

            redirect('ProjectController/login');
        }
    }

    // logout
    public function logout()
    {
        $this->session->sess_destroy();

        redirect('ProjectController/login');
    }

    // save
    public function save()
    {
        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim'
        );

        if ($this->form_validation->run() == FALSE) {

            $data['items'] = $this->ProjectModel->get_items();

            $this->load->view('ProjectView', $data);

            return;
        }

        // upload
        $image = '';

        if (!empty($_FILES['image']['name'])) {

            $config['upload_path'] = './uploads/items/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 2048;
            $config['encrypt_name'] = TRUE;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {

                $upload_data = $this->upload->data();

                $image = $upload_data['file_name'];

            } else {

                $this->session->set_flashdata(
                    'error',
                    $this->upload->display_errors()
                );

                redirect('ProjectController');
            }
        }

        // insert
        $data = array(
            'student_id' => $this->input->post('student_id', TRUE),
            'item_name' => $this->input->post('item_name', TRUE),
            'description' => $this->input->post('description', TRUE),
            'location' => $this->input->post('location', TRUE),
            'date_lost' => $this->input->post('date_lost', TRUE),
            'contact' => $this->input->post('contact', TRUE),
            'status' => 'Lost',
            'image' => $image
        );

        if ($this->ProjectModel->insert_item($data)) {

            $this->session->set_flashdata(
                'success',
                'Lost item added successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to add lost item.'
            );
        }

        redirect('ProjectController');
    }

    // edit
    public function edit($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $data['item'] = $this->ProjectModel->get_item($id);

        if (!$data['item']) {

            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        $this->load->view('ProjectEdit', $data);
    }

    // update
    public function update($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        // validation
        $this->form_validation->set_rules(
            'student_id',
            'Student ID',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'item_name',
            'Item Name',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'location',
            'Location',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'date_lost',
            'Date Lost',
            'required'
        );

        $this->form_validation->set_rules(
            'contact',
            'Contact',
            'required|trim'
        );

        $this->form_validation->set_rules(
            'description',
            'Description',
            'required|trim'
        );

        if ($this->form_validation->run() == FALSE) {

            $data['item'] = $this->ProjectModel->get_item($id);

            $this->load->view('ProjectEdit', $data);

            return;
        }

        // get old item
        $old_item = $this->ProjectModel->get_item($id);

        // update
        $data = array(
            'student_id' => $this->input->post('student_id', TRUE),
            'item_name' => $this->input->post('item_name', TRUE),
            'description' => $this->input->post('description', TRUE),
            'location' => $this->input->post('location', TRUE),
            'date_lost' => $this->input->post('date_lost', TRUE),
            'contact' => $this->input->post('contact', TRUE),
            'status' => $this->input->post('status', TRUE)
        );

        // upload
        if (!empty($_FILES['image']['name'])) {

            $config['upload_path'] = './uploads/items/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 2048;
            $config['encrypt_name'] = TRUE;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {

                $upload_data = $this->upload->data();

                $data['image'] = $upload_data['file_name'];

                if (!empty($old_item->image)) {

                    $old_image = './uploads/items/' . $old_item->image;

                    if (file_exists($old_image)) {
                        unlink($old_image);
                    }
                }

            } else {

                $this->session->set_flashdata(
                    'error',
                    $this->upload->display_errors()
                );

                redirect('ProjectController/edit/' . $id);
            }
        }

        if ($this->ProjectModel->update_item($id, $data)) {

            $this->session->set_flashdata(
                'success',
                'Lost item updated successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to update lost item.'
            );
        }

        redirect('ProjectController');
    }

    // delete
    public function delete($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        if ($this->ProjectModel->delete_item($id)) {

            $this->session->set_flashdata(
                'success',
                'Lost item deleted successfully.'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Failed to delete lost item.'
            );
        }

        redirect('ProjectController');
    }

    // dashboard
    public function dashboard()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $data['lost'] = $this->ProjectModel->count_lost();

        $data['found'] = $this->ProjectModel->count_found();

        $data['total'] = $data['lost'] + $data['found'];

        $this->load->view('Dashboard', $data);
    }

    // notify
    public function notify($id)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('ProjectController/login');
        }

        $student_id = $this->input->post('student_id', TRUE);
        $email = $this->input->post('email', TRUE);

        if (empty($student_id)) {

            $this->session->set_flashdata(
                'error',
                'Student ID is required.'
            );

            redirect('ProjectController');
        }

        if (empty($email)) {

            $this->session->set_flashdata(
                'error',
                'Email is required.'
            );

            redirect('ProjectController');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $this->session->set_flashdata(
                'error',
                'Please enter a valid email address.'
            );

            redirect('ProjectController');
        }

        $item = $this->ProjectModel->get_item($id);

        if (!$item) {

            $this->session->set_flashdata(
                'error',
                'Item not found.'
            );

            redirect('ProjectController');
        }

        // notification
        $data = array(
            'item_id' => $id,
            'student_id' => $student_id,
            'message' =>
                'Student ' . $student_id .
                ' was notified about ' . $item->item_name
        );

        if (!$this->ProjectModel->create_notification($data)) {

            $this->session->set_flashdata(
                'error',
                'Notification failed.'
            );

            redirect('ProjectController');
        }

        // email
        $this->email->from(
            $this->config->item('smtp_user'),
            'Lost and Found System'
        );

        $this->email->to($email);

        $this->email->subject(
            'Lost and Found Notification - ' . $item->item_name
        );

        $message = '
            <h3>Lost and Found Notification</h3>

            <p>Hello,</p>

            <p>Your lost item has been matched with a reported item.</p>

            <p><strong>Student ID:</strong> ' . html_escape($student_id) . '</p>

            <p><strong>Item Name:</strong> ' . html_escape($item->item_name) . '</p>

            <p><strong>Description:</strong> ' . html_escape($item->description) . '</p>

            <p><strong>Location:</strong> ' . html_escape($item->location) . '</p>

            <p><strong>Date Lost:</strong> ' . html_escape($item->date_lost) . '</p>

            <p><strong>Contact:</strong> ' . html_escape($item->contact) . '</p>

            <p>Please check the attached image of the item.</p>

            <p>Thank you.</p>
        ';

        $this->email->message($message);

        // attachment
        if (!empty($item->image)) {

            $file_path = FCPATH . 'uploads/items/' . $item->image;

            if (file_exists($file_path)) {
                $this->email->attach($file_path);
            }
        }

        if ($this->email->send()) {

            $this->session->set_flashdata(
                'success',
                'Notification recorded and email sent successfully.'
            );

        } else {

            log_message(
                'error',
                $this->email->print_debugger()
            );

            $this->session->set_flashdata(
                'error',
                'Notification was recorded, but the email could not be sent.'
            );
        }

        redirect('ProjectController');
    }
}