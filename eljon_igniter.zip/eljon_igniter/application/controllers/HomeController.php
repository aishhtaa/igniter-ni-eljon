<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('studentDB');
	}	

	public function index()
	{	
			

		$this->load->view('home');
	}


	public function save()
	{

		if ($this->input->post('submit')) {
		
		

		$data = array(
			'fullname' =>
		$this->input->post('fullname'),
				'email' => $this->input->post('email'),
				'course' =>		
		$this->input->post('course'),
				'year_level' =>
		$this->input->post('year_level'),		
				'address' =>
		$this->input->post('address'),
				'contact_number' =>
		$this->input->post('contact_number')
			);

		$results = $this->studentDB->insertStudents($data);

		if ($results) {
			redirect('HomeController/Studentdb');
		} else {
			echo "error";
		}

		}

		
		}	

	public function about()
	{
		$this->load->view('about');
	}

	public function Studentdb()
	{
		$getdata['students'] = $this->studentDB->fetchStudents();
	
		$this->load->view('Studentdb', $getdata);
	}

	public function edit($id)
	{
    $data['student'] = $this->studentDB->get_Id_Student($id);

    if (empty($data['student'])) {
        redirect('HomeController/Studentdb');
    }

    $this->load->view('edit', $data);
  	}

  	public function update($id)
	{
    if ($this->input->post('submit')) {

        $data = array(
            'fullname' => $this->input->post('fullname'),
            'email' => $this->input->post('email'),
            'course' => $this->input->post('course'),
            'year_level' => $this->input->post('year_level'),
            'address' => $this->input->post('address'),
            'contact_number' => $this->input->post('contact_number')
        );

        $results = $this->studentDB->updateStudent($id, $data);

        if ($results) {
            redirect('HomeController/Studentdb');
        } else {
            echo "Error";
        }
     }

  }
   public function delete($id)
	 {
    $results = $this->studentDB->deleteStudent($id);

    if ($results) {
        redirect('HomeController/Studentdb');
    } else {
        echo "Error deleting student";
    }
 }
}


